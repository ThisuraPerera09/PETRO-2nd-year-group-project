<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Background Change Automatic - Sagar Developer</title>
    <link rel="stylesheet" href="<?php echo ROOT?>/CSS/Common/login.css">
    <link rel="stylesheet" href="<?php echo ROOT?>/CSS/Common/Not_found.css">
</head>

<body>
    <div class="Section_top">

        <div class="wrapper">
            <h2>Oops !!</h2>
            <h3>Page Not Found</h3>

        </div>
    </div>

</body>

</html>