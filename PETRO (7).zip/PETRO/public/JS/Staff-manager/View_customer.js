let selectMenu = document.querySelector("#filter");
let container = document.querySelector(".table");

//take event by select options by catagry dropdown
selectMenu.addEventListener("changes", function(){
    let catogoryName = this.value;

    let http = new XMLHttpRequest();
    print("done");
    console.log("done");
    http.open('POST', "../../../../app/Staff-manager/View_pumper")

});