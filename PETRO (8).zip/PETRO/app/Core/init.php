<?php

require 'config.php';
require 'Helpers.php';
require 'Database.php';
require 'Model.php';
require 'Controller.php';
require 'App.php';

