

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Background Change Automatic - Sagar Developer</title>
    <link rel="stylesheet" href="<?php echo ROOT?>/CSS/Customer/terms.css" text="text/css">

</head>

<body>
    <div class="Section_top">
        <header>
            <a href="#"><img src="<?php echo ROOT ?>/image/Common/log.png" alt="" class="image"></a>
        </header>
        <div class="wrapper">
          


           <br><br><br>       
        <ul>
  <li class="terms">When you place a fuel order you should complete that within 2 days.Otherwise Order will cancel.</li>
  <li class="terms">You can Only place one order for one vehicle/Machine per time.If you want to place another order for same Vehicle/Machine
    you should first complete the privious order
  </li>
  <li class="terms">If you cannot fully complete the order you can come back and complete that order within 2 days </li>
  <li class="terms">You hould come to the filling station with your Order Ticket.It will send to your email after you place an Order.
    If you didn't place an order before you can generate a order with your mobile number but you cannot get the petro points </li>
    <li class="terms">We have a lubrican store but we only do the delivery.</li>
  <li class="terms">There is a Maximum amount of liters that you can order at once according to your vehicle type</li>
  <li class="terms">You will get a relevant number of points after you complete your order. You can redeem that points after it exceeds more than 100.</li>
  <li class="terms">If the petro points exceeds 300 it will automatically reduced from your bill</li>
  <li class="terms">You will get 1 petro points per any type of fuel liter and 5 Petro points for any type of Lubricant. ! petro points equals to 1 Rupee.</li>
  <li class="terms">We only do delivery from our Store. You cannot come and collect the product from the filling station</li>
  


</ul>  




        </div>
    </div>


    





 
 






</body>
</html>










